#Logan Miranowski
#INF360 - Programming with Python
#Final Project

import logging

# Set up logging
logging.basicConfig(filename='game_log.txt', level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')



#Define game areas and movement options
game_map = {
    "start": {
        "north": "Cliff of Doom",
        "east": "Peaceful Road to Peace",
        "south": "Certain Death",
        "west": "Path of Demise"
    },
    "Cliff of Doom": {}, # Death
    "Certain Death": {}, # Death
    "Path of Demise": {}, # Death
    "Peaceful Road to Peace": {
        "north": "Pool of Liquid of Unknown Origin", 
        "east": "Great Dragon of the East", 
        "south": "Princess Tower", 
        "west": "return to start"
    },
    "Pool of Liquid of Unknown Origin": {}, # Death
    "Great Dragon of the East": {}, # Death
    "return to start": {"north": "Cliff of Doom",
        "east": "Peaceful Road to Peace",
        "south": "Certain Death",
        "west": "Path of Demise"}, # Return to the start
    "Princess Tower": {
        "north": "previous",
          "east": "Great Dragon of the South East", 
          "south": "Freakin Sharks with Lasers", 
          "west": "Retirement"
    },
    "Great Dragon of the South East": {}, # Death
    "Freakin Sharks with Lasers": {}, # Death
    "return to Peaceful Road to Peace": {"north": "Peaceful Road to Peace"}, # Return to the Peaceful Road to Peace
    "Retirement": {} # Victory
}

#Messages for each deadly area
death_messages = {
    "Cliff of Doom": "You stepped too close to the edge and plummeted into the abyss. Your adventure ends here.",
    "Certain Death": "You walked straight into a trap, and your fate was sealed. Rest in pieces.",
    "Path of Demise": "A shadowy figure emerged, before you could react, you were no more.",
    "Pool of Liquid of Unknown Origin": "You took a sip. Bad choice. The world fades to black.",
    "Great Dragon of the East": "A massive dragon roared and turned you to ash with a single breath.",
    "Great Dragon of the South East": "You barely had time to blink before the dragon's claws ended your journey.",
    "Freakin Sharks with Lasers": "You never knew sharks could have lasers...until one zapped you into oblivion."
}

class Game:
    def __init__(self):
        self.current_area = "start"
        self.visited_areas = set()  # set to keep track of visited areas

    def start(self):
        print("Welcome to Lord Logan's Princess Saving Game!")
        print("This program does not save your progress.")
        self.decision(self.current_area)
    
    def end_conditions(self, death_location):
    # Handles game-over conditions.
        death_message = death_messages.get(death_location, "You have met a terrible fate.")
        
        logging.critical(f"Player died in {death_location} due to {death_message}")
        print(f"\n{death_message}")
        print("Game over. Thank you for playing.")

        play_again = input("Would you like to play again? (yes/no): ").strip().lower()

        if play_again == "yes":
            self.__init__()
            self.start()
        else:
            print("Goodbye!")
            exit()

    def decision(self, current_area):
        #Handles user input, and game progression
        print(f"\nYou have arrived at {current_area}.")
        logging.debug(f"Player entered {current_area}.")

        if not game_map[current_area]: # Check if there are any choices
            print("You have no choices here. You are dead.")
            self.end_conditions(current_area)
            return
        
        print("You can go:")
        for direction, location in game_map[current_area].items():
            print(f" - {direction.capitalize()} to {location}")

        while True:
            choice = input("Which way do you go? ").lower()
    
            if choice in game_map[current_area]: # Check if the choice is valid
                next_area = game_map[current_area][choice]

                if next_area in self.visited_areas:
                    logging.critical(f"Player tried to go back to {next_area} after visiting it.")                    
                    print(f"You tried to go back to {next_area}, but you soon find out a man has been following you. You are dead. Never go backwards. Lesson learned.")
                    self.end_conditions(next_area) #call end_conditions function after death message
                    return 
                
                if next_area in death_messages:
                    self.end_conditions(next_area) #call end_conditions function after death message
                    return
                
                self.visited_areas.add(next_area)
                self.continue_game(current_area, choice)
                return
            else:
                logging.warning(f"Player made an invalid choice: {choice} in {current_area}.")
                print(f"Invalid choice '{choice}'. Please choose one of the valid directions.")
        

    def continue_game(self, current_area, choice):
        #Handles correct choices and updates the current area.
        next_area = game_map[current_area].get(choice)
        if next_area == "Retirement":
            print("\nCongratulations on saving the princess and winning the game!") 
            logging.info("Player reached the Retirement area and won the game.")   

            play_again = input("Would you like to play again? (yes/no): ").strip().lower()

            if play_again == "yes":
                self.__init__()
                self.start()
            else:
                print("Goodbye!")
                exit()     
            return 
    
        self.decision(next_area)
    

if __name__ == "__main__":
    game = Game()
game.start() # Start the game
        

